﻿var msalconfig = {
    clientID: "c7cb7b62-984f-4e72-b273-94accc2fedb0",
    redirectUri: "http://localhost:30662/"
};